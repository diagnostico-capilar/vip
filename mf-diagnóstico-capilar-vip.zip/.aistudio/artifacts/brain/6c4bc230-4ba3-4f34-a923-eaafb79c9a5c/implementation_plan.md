# Nova Página de Vendas MF Diagnóstico Capilar — Exclusiva para Cabeleireiros

Reformulação completa da landing page comercial do MF Diagnóstico Capilar com foco 100% voltado para cabeleireiros e proprietários de salões de beleza, transformando o diagnóstico capilar em uma oportunidade profissional de relacionamento, consulta qualificada e venda de tratamentos com design sofisticado e alta conversão.

## Decisões Críticas e Preferências Confirmadas

> [!IMPORTANT]
> **Alinhamentos confirmados pelo usuário:**
> - **Público Exclusivo**: Foco 100% em **Cabeleireiros e Proprietários de Salões de Beleza** (conforme instrução expressa "SÓ PARA CABELEIREIROS"). Seções para distribuidores foram removidas do fluxo principal para máxima relevância e persuasão.
> - **Estilo Visual**: Sofisticado escuro (`#0B0F17` / `#131B2A`) com detalhes elegantes em dourado nobre (`#D4AF37`) e champagne suave (`#F5E6CA`), transmitindo autoridade em tecnologia e cosmética profissional sem parecer laboratorial ou genérico.
> - **Simulador Financeiro**: Calculadora interativa ilustrativa com controles para atendimentos mensais e margem média, acompanhada de advertência clara de que se trata de modelo matemático ilustrativo e não garantia de faturamento.
> - **Transparência e Regras Éticas**: Sem contadores falsos, sem depoimentos inventados, sem promessas milagrosas de crescimento capilar, e sem telas forjadas do sistema. Link oficial do diagnóstico preservado (`https://diagnosticovip.vercel.app/diagnostico/mfcosmeticos`).

---

## 1. Visão Geral e Proposta de Valor

### O Que a Solução Oferece
Uma landing page comercial moderna, persuasiva e de carregamento ultrarrápido que apresenta o MF Diagnóstico Capilar aos profissionais da beleza. A ferramenta permite que as clientes do salão respondam a um questionário sobre suas queixas e rotina capilar antes ou durante o atendimento, entregando ao cabeleireiro dados organizados para conduzir uma conversa personalizada, justificar recomendações técnicas e oferecer os tratamentos e produtos ideais.

### Público-Alvo e Persona
- Cabeleireiros autônomos, coloristas, terapeutas capilares e proprietários de salões de beleza que buscam valorizar seu atendimento, elevar a percepção de valor dos seus serviços e criar oportunidades éticas de tratamentos personalizados.

### Proposta Central
> *"Transforme o diagnóstico capilar em uma nova oportunidade de relacionamento e vendas para o seu negócio."*

---

## 2. Experiência do Usuário e Design Visual

### Jornada do Visitante (12 Seções Estratégicas)
1. **Header Fixo / Top Bar**: Wordmark institucional "MF Cosméticos Profissionais", links de navegação rápida (*Como Funciona*, *Benefícios*, *Demonstração*, *Simulação*, *FAQ*) e CTA prioritário *"Falar no WhatsApp"*.
2. **Hero Section (Primeira Dobra)**:
   - Título oficial do briefing: *"Seu salão pode ir além de oferecer serviços. Conheça melhor cada cliente e crie novas oportunidades de vender tratamentos capilares."*
   - Subtítulo explicativo com a dinâmica de resposta da cliente e orientação técnica do profissional.
   - Botão Primário: **"QUERO CONHECER O DIAGNÓSTICO CAPILAR"** (WhatsApp com mensagem pré-preenchida para cabeleireiros).
   - Botão Secundário: **"VER COMO FUNCIONA"** (rolagem suave até a seção de funcionamento).
   - Composição visual fotográfica de salão premium com mockups elegantes de celular demonstrando o fluxo do questionário.
3. **Identificação do Problema no Salão**:
   - Título: *"Você conhece as necessidades dos cabelos das suas clientes ou só descobre quando elas chegam ao salão?"*
   - Grade de 6 desafios cotidianos (ressecamento/quebra não antecipados, cliente indecisa, dificuldade para justificar tratamentos, compra de produtos sem orientação, perda de contato entre visitas, diferenciação no mercado).
   - Fechamento: *"O primeiro passo para oferecer um tratamento adequado é conhecer melhor a necessidade da cliente."*
4. **Apresentação da Solução**:
   - Três pilares fundamentais: *1. Conheça melhor a cliente*, *2. Personalize a conversa*, *3. Crie oportunidades comerciais*.
5. **Como Funciona na Prática (5 Etapas Intuitivas)**:
   - Etapa 1: Cabeleireiro compartilha o link com a cliente.
   - Etapa 2: Cliente acessa e responde às perguntas sobre necessidades capilares.
   - Etapa 3: Cabeleireiro recebe as respostas diretamente no WhatsApp cadastrado.
   - Etapa 4: Cabeleireiro orienta o tratamento com embasamento nas respostas relatadas.
   - Etapa 5: Manutenção do relacionamento e acompanhamento contínuo.
6. **Demonstração do Produto & Prévia Real**:
   - Título: *"Antes de contratar, entenda o que sua cliente vai utilizar."*
   - Mockups fieis da jornada: tela inicial de acolhimento, seleção de histórico de químicas e queixas, resumo recebido pelo cabeleireiro no WhatsApp.
   - Botão para testar o questionário oficial com aviso transparente de que é o link de produção: `https://diagnosticovip.vercel.app/diagnostico/mfcosmeticos`.
   - Botão comercial: *"QUERO SABER COMO FUNCIONA"* (WhatsApp).
7. **Benefícios Exclusivos para Cabeleireiros**:
   - Valorização da consulta técnica, aumento de autoridade, fidelização e diferenciação perante a concorrência.
   - Citação de destaque: *"Não se trata apenas de oferecer um tratamento. Trata-se de entender a necessidade da cliente e explicar por que determinada solução pode fazer sentido para ela."*
8. **Simulador de Retorno do Investimento (Interativo & Transparente)**:
   - Exemplo matemático do briefing integrado a controles interativos:
     - Sliders: Quantidade de tratamentos adicionais por mês (padrão: 4) e Margem média por tratamento (padrão: R$ 80).
     - Resultado em tempo real: `4 × R$ 80 = R$ 320` de margem de contribuição adicional antes de custos de ferramenta e insumos.
   - Disclaimer obrigatório destacado: *"Este é apenas um exemplo matemático para demonstrar como avaliar a viabilidade da ferramenta. Não representa uma previsão ou garantia de vendas ou resultados financeiros."*
9. **Credibilidade e Autoridade Institucional**:
   - MF Cosméticos Profissionais: **Mais de 32 anos de experiência no mercado profissional da beleza**.
   - Compromisso com produtos profissionais, ética e suporte direto.
10. **Condições Comerciais e Contratação Descomplicada**:
    - Explicação clara de como contratar via atendimento comercial, processo de ativação e cadastro do número de WhatsApp do salão.
    - Área modular pronta para futura exibição de planos e preços quando definidos.
    - CTA: **"QUERO CONTRATAR O DIAGNÓSTICO CAPILAR"** (WhatsApp).
11. **FAQ Interativo em Acordeão (11 Perguntas Oficiais)**:
    - Respostas precisas, sem dados inventados, esclarecendo que não substitui diagnóstico médico, que as respostas vão para o WhatsApp cadastrado e que a ferramenta potencializa o relacionamento.
12. **Chamada Final & Botão Flutuante de WhatsApp**:
    - Fechamento convincente com dados de contato oficiais: `(19) 9.8359-6993` (`https://wa.me/5519983596993`).
    - Botão flutuante sutil no canto inferior direito respeitando a regra de até 15% do viewport mobile.

### Identidade Visual & Paleta
- **Canvas Base**: `#080C14` (Obsidiana profundo) com gradientes radiais suaves e cartões em `#0F1626` com bordas sutis em `#1E293B` e toques em `#D4AF37`/`#F5E6CA`.
- **Acentos Dourados**: `#D4AF37` (Ouro metálico), `#ECC94B` (Champagne brilho), `#996515` (Dourado profundo para bordas e badges).
- **Tipografia**: `Plus Jakarta Sans` para títulos e `Inter/Plus Jakarta Sans` para textos, com pesos bem distribuídos e `text-wrap: balance`.

---

## 3. Decisões Técnicas e Comerciais

| Decisão | Opção Escolhida | Racional Técnico/Comercial |
| :--- | :--- | :--- |
| **Público Único** | 100% Cabeleireiros | O cliente instruiu "SÓ PARA CABELEIREIROS". Eliminar distrações eleva drasticamente a taxa de conversão e a clareza da proposta de valor. |
| **Integração WhatsApp** | Links `wa.me/5519983596993` com encode URI | Rápido, direto, sem fricção de formulários desnecessários ou dependência de banco de dados para captura de leads. |
| **Simulador de ROI** | Slider reativo React com cálculo dinâmico | Permite ao cabeleireiro testar sua própria realidade (ex: 2 a 20 tratamentos/mês) mantendo o disclaimer legal obrigatório visível. |
| **Mídia e Imagens** | Geração em lote via `generate_image` | Evita URLs externas quebradas (`unsplash/picsum`) e gera fotografias realistas de atendimento de salão e cabeleireira profissional. |

---

## 4. Arquitetura de Componentes e Estrutura de Código

```
┌────────────────────────────────────────────────────────┐
│                   App.tsx (Root Layout)                │
├────────────────────────────────────────────────────────┤
│ ├── Navbar (Top Bar Contract: Brand · Links · CTA)     │
│ ├── HeroSection (Título Oficial · Copy · CTAs · Foto)  │
│ ├── ProblemSection (6 Desafios Reais no Salão)         │
│ ├── SolutionSection (3 Pilares de Valor)               │
│ ├── HowItWorksSection (5 Etapas Práticas)              │
│ ├── DemoPreviewSection (Jornada Cliente · Link Oficial)│
│ ├── HairdresserBenefitsSection (Autoridade & Consulta) │
│ ├── RoiCalculatorSection (Simulador Interativo)        │
│ ├── CredibilitySection (MF Cosméticos 32+ Anos)        │
│ ├── OfferSection (Processo de Contratação & Ativação)  │
│ ├── FaqSection (11 Perguntas Oficiais em Acordeão)     │
│ ├── FinalCtaSection (Chamada Final & Contato Oficial)  │
│ ├── FloatingWhatsapp (Botão Flutuante Responsivo)      │
│ └── Footer (Direitos · Links Institucionais)           │
└────────────────────────────────────────────────────────┘
```

### URLs e Parâmetros Oficiais Integrados
- **WhatsApp Comercial**: `https://wa.me/5519983596993`
- **Mensagem para Cabeleireiros**:
  `Olá! Quero conhecer o MF Diagnóstico Capilar para utilizar no meu salão. Gostaria de saber como funciona e quais são as condições de contratação.`
- **Mensagem para Demonstração**:
  `Olá! Gostaria de ver uma demonstração do MF Diagnóstico Capilar antes de contratar.`
- **Link Oficial do Diagnóstico**:
  `https://diagnosticovip.vercel.app/diagnostico/mfcosmeticos`
- **Telefone em exibição**: `(19) 9.8359-6993`
