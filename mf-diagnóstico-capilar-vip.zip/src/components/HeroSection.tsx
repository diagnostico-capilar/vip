import React from 'react';
import { ArrowDown, MessageCircle, Sparkles, CheckCircle2, Smartphone, ShieldCheck, HeartHandshake } from 'lucide-react';
import { WHATSAPP_MESSAGES, getWhatsAppUrl, COMPANY_EXPERIENCE } from '../constants/links';

export const HeroSection: React.FC = () => {
  return (
    <section className="relative overflow-hidden pt-12 pb-20 lg:pt-18 lg:pb-28 bg-[#080C14]">
      {/* Background ambient lighting */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-7xl h-96 bg-radial-gold pointer-events-none" />
      <div className="absolute -top-24 right-10 w-96 h-96 bg-[#D4AF37]/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute top-1/2 -left-20 w-80 h-80 bg-[#1E293B]/40 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          
          {/* Coluna de Texto (Copy Oficial) */}
          <div className="lg:col-span-7 text-left space-y-6">
            
            {/* Tag discreta para cabeleireiros */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#131B2A] border border-[#D4AF37]/30 text-xs font-semibold text-[#E8C872]">
              <Sparkles className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span>Exclusivo para Cabeleireiros e Proprietários de Salões</span>
            </div>

            {/* Título Principal Oficial */}
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white tracking-tight leading-[1.15] text-balance">
              Seu salão pode ir além de oferecer serviços.{' '}
              <span className="text-gold-gradient block mt-2">
                Conheça melhor cada cliente e crie novas oportunidades de vender tratamentos capilares.
              </span>
            </h1>

            {/* Subtítulo Oficial */}
            <p className="text-base sm:text-lg text-slate-300 leading-relaxed max-w-2xl">
              Com o <strong className="text-white font-semibold">MF Diagnóstico Capilar</strong>, sua cliente responde a perguntas sobre as necessidades dos cabelos e você recebe as informações para orientar uma conversa mais personalizada sobre cuidados, produtos e tratamentos.
            </p>

            {/* Frase Complementar Oficial */}
            <div className="p-4 rounded-xl bg-[#0E1524] border border-slate-800/90 text-sm text-slate-300 flex items-start gap-3">
              <HeartHandshake className="w-5 h-5 text-[#D4AF37] shrink-0 mt-0.5" />
              <span>
                Uma ferramenta para aproximar você das suas clientes, valorizar seu atendimento e ajudar a identificar oportunidades de tratamento.
              </span>
            </div>

            {/* Botões de Ação */}
            <div className="pt-2 flex flex-col sm:flex-row items-stretch sm:items-center gap-4">
              <a
                href={getWhatsAppUrl(WHATSAPP_MESSAGES.HAIRDRESSER)}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-2.5 px-7 py-4 rounded-xl text-sm sm:text-base font-bold text-[#080C14] bg-gradient-to-r from-[#F5E6CA] via-[#E8C872] to-[#D4AF37] hover:brightness-110 active:scale-95 transition-all shadow-lg shadow-[#D4AF37]/20 whitespace-nowrap"
              >
                <MessageCircle className="w-5 h-5 fill-current" />
                <span>QUERO CONHECER O DIAGNÓSTICO CAPILAR</span>
              </a>

              <a
                href="#como-funciona"
                className="inline-flex items-center justify-center gap-2 px-6 py-4 rounded-xl text-sm sm:text-base font-semibold text-slate-200 bg-[#131B2A] hover:bg-[#1A2438] border border-slate-700/80 transition-all hover:text-white"
              >
                <span>VER COMO FUNCIONA</span>
                <ArrowDown className="w-4 h-4 text-[#D4AF37]" />
              </a>
            </div>

            {/* Micro Provas & Garantias Institucionais */}
            <div className="pt-4 flex flex-wrap items-center gap-y-2 gap-x-6 text-xs text-slate-400">
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-[#D4AF37]" />
                <span>{COMPANY_EXPERIENCE}</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-[#D4AF37]" />
                <span>Respostas direto no seu WhatsApp</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-[#D4AF37]" />
                <span>Sem aplicativos pesados para a cliente</span>
              </div>
            </div>

          </div>

          {/* Coluna Visual: Representação Elegante do Diagnóstico no Celular e Salão */}
          <div className="lg:col-span-5 flex justify-center">
            <div className="relative w-full max-w-md">
              
              {/* Moldura de Smartphone com o fluxo do diagnóstico */}
              <div className="relative mx-auto w-[290px] sm:w-[320px] rounded-[42px] bg-[#0A0E17] border-[6px] border-slate-800 p-3 shadow-2xl shadow-[#D4AF37]/10">
                {/* Speaker e câmera notch */}
                <div className="w-24 h-4 bg-slate-800 rounded-full mx-auto mb-3" />

                {/* Tela do Celular */}
                <div className="rounded-[30px] bg-[#0E1524] p-4 text-left border border-slate-800 space-y-4">
                  {/* Topo do App */}
                  <div className="flex items-center justify-between pb-3 border-b border-slate-800/80">
                    <div className="flex items-center gap-2">
                      <div className="w-6 h-6 rounded-md bg-[#D4AF37] flex items-center justify-center">
                        <span className="text-[10px] font-black text-black">MF</span>
                      </div>
                      <span className="text-xs font-bold text-white">Diagnóstico Capilar</span>
                    </div>
                    <span className="text-[10px] text-[#D4AF37] font-semibold bg-[#D4AF37]/10 px-2 py-0.5 rounded-full">
                      Passo 2 de 5
                    </span>
                  </div>

                  {/* Pergunta Simulada */}
                  <div className="space-y-1.5">
                    <p className="text-[11px] text-[#E8C872] uppercase font-semibold tracking-wider">
                      Necessidades Informadas
                    </p>
                    <p className="text-sm font-bold text-white leading-snug">
                      Como você sente o comprimento e as pontas do seu cabelo hoje?
                    </p>
                  </div>

                  {/* Opções de Resposta selecionadas pela cliente */}
                  <div className="space-y-2 text-xs">
                    <div className="p-2.5 rounded-lg bg-[#D4AF37]/15 border border-[#D4AF37]/40 text-white flex items-center justify-between">
                      <span className="font-medium">Ressecado e com pontas duplas</span>
                      <CheckCircle2 className="w-4 h-4 text-[#D4AF37]" />
                    </div>
                    <div className="p-2.5 rounded-lg bg-[#141C2E] border border-slate-800 text-slate-300">
                      <span>Quebradiço após descoloração/química</span>
                    </div>
                    <div className="p-2.5 rounded-lg bg-[#141C2E] border border-slate-800 text-slate-300">
                      <span>Sem brilho e com frizz constante</span>
                    </div>
                  </div>

                  {/* Notificação recebida no WhatsApp da Cabeleireira */}
                  <div className="p-3 rounded-xl bg-[#091D17] border border-emerald-600/30 space-y-1 text-left">
                    <div className="flex items-center gap-1.5 text-emerald-400 text-[11px] font-bold">
                      <MessageCircle className="w-3.5 h-3.5 fill-current" />
                      <span>WhatsApp da Cabeleireira</span>
                    </div>
                    <p className="text-[11px] text-emerald-100/90 leading-tight">
                      <strong>Nova Análise Recebida:</strong> Cliente Marina relatou queixas de ressecamento pós-mechas. Sugestão: Cronograma de Nutrição & Reconstrução Profissional.
                    </p>
                  </div>
                </div>

                {/* Barra inferior do celular */}
                <div className="w-28 h-1 bg-slate-700 rounded-full mx-auto mt-4" />
              </div>

              {/* Card flutuante de autoridade */}
              <div className="absolute -bottom-6 -left-4 sm:-left-8 bg-[#0E1524]/95 backdrop-blur-md border border-[#D4AF37]/30 rounded-2xl p-4 shadow-xl max-w-[240px] text-left">
                <div className="flex items-center gap-2 mb-1.5">
                  <div className="w-8 h-8 rounded-lg bg-[#D4AF37]/20 flex items-center justify-center text-[#D4AF37]">
                    <Smartphone className="w-4 h-4" />
                  </div>
                  <div>
                    <p className="text-xs font-bold text-white leading-tight">100% Digital</p>
                    <p className="text-[10px] text-slate-400">Direto no WhatsApp</p>
                  </div>
                </div>
                <p className="text-[11px] text-slate-300 leading-tight">
                  Sua cliente não precisa baixar nenhum aplicativo para responder.
                </p>
              </div>

            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
