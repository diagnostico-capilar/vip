import React from 'react';
import { COMPANY_NAME, COMPANY_EXPERIENCE, WHATSAPP_PHONE_DISPLAY, WHATSAPP_MESSAGES, getWhatsAppUrl, OFFICIAL_DIAGNOSIS_URL } from '../constants/links';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-[#05080E] border-t border-slate-800 text-slate-400 text-xs py-14">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
        
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6 pb-8 border-b border-slate-800/80">
          <div className="space-y-1">
            <span className="text-base sm:text-lg font-bold text-white tracking-tight">
              {COMPANY_NAME}
            </span>
            <p className="text-slate-400 text-xs">
              MF Diagnóstico Capilar · Solução digital para salões de beleza e cabeleireiros
            </p>
            <p className="text-[11px] text-[#D4AF37] font-medium pt-1">
              {COMPANY_EXPERIENCE}
            </p>
          </div>

          <nav className="flex flex-wrap items-center gap-6 text-slate-400">
            <a href="#como-funciona" className="hover:text-white transition-colors">Como Funciona</a>
            <a href="#demonstracao" className="hover:text-white transition-colors">Demonstração</a>
            <a href="#beneficios" className="hover:text-white transition-colors">Benefícios</a>
            <a href="#simulacao" className="hover:text-white transition-colors">Simulador</a>
            <a href="#faq" className="hover:text-white transition-colors">Perguntas Frequentes</a>
            <a 
              href={OFFICIAL_DIAGNOSIS_URL} 
              target="_blank" 
              rel="noopener noreferrer" 
              className="text-[#D4AF37] hover:underline"
            >
              Questionário Oficial
            </a>
          </nav>
        </div>

        <div className="space-y-3 text-[11px] text-slate-400 leading-relaxed max-w-4xl">
          <p>
            <strong>Aviso de responsabilidade técnica:</strong> O MF Diagnóstico Capilar é uma ferramenta digital desenvolvida para auxiliar cabeleireiros profissionais na organização das queixas relatadas por clientes. A ferramenta não substitui o diagnóstico clínico presencial nem a consulta com profissionais de saúde (médicos ou dermatologistas).
          </p>
          <p>
            Contato Comercial Oficial: <strong className="text-slate-300">{WHATSAPP_PHONE_DISPLAY}</strong>. Todos os direitos reservados © {new Date().getFullYear()} {COMPANY_NAME}.
          </p>
        </div>

      </div>
    </footer>
  );
};
