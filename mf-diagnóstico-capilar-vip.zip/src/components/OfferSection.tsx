import React from 'react';
import { MessageCircle, CheckCircle2, ShieldCheck, Clock, KeyRound, Sparkles } from 'lucide-react';
import { WHATSAPP_MESSAGES, getWhatsAppUrl, WHATSAPP_PHONE_DISPLAY } from '../constants/links';

export const OfferSection: React.FC = () => {
  const steps = [
    {
      num: '1',
      title: 'Conversa Inicial',
      desc: 'Entre em contato com a equipe comercial no WhatsApp para conhecer os modelos de contratação e tirar dúvidas.',
    },
    {
      num: '2',
      title: 'Configuração do Salão',
      desc: 'Cadastramos o seu número de WhatsApp profissional para receber os relatórios das suas clientes.',
    },
    {
      num: '3',
      title: 'Link Ativo para Compartilhar',
      desc: 'Você recebe seu link exclusivo e já pode começar a divulgar nas redes e enviar para suas clientes.',
    },
  ];

  return (
    <section className="py-20 lg:py-28 bg-[#080C14] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Cabeçalho */}
        <div className="max-w-3xl mx-auto text-center space-y-4 mb-16">
          <span className="text-xs font-bold text-[#D4AF37] tracking-widest uppercase">
            Contratação e Ativação
          </span>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-white tracking-tight leading-snug">
            Leve o MF Diagnóstico Capilar para o seu negócio.
          </h2>
          <p className="text-slate-300 text-sm sm:text-base leading-relaxed">
            Conheça as condições para utilizar o Diagnóstico Capilar e descubra como essa ferramenta pode fazer parte da sua estratégia de atendimento e venda de tratamentos.
          </p>
          <p className="text-slate-400 text-sm leading-relaxed max-w-2xl mx-auto">
            Converse diretamente com a equipe da MF Cosméticos para conhecer o funcionamento detalhado, o processo de ativação, os recursos disponíveis e as condições comerciais vigentes.
          </p>
        </div>

        {/* Card Principal da Oferta */}
        <div className="max-w-4xl mx-auto rounded-3xl bg-gradient-to-b from-[#0E1524] to-[#0A0E17] border border-[#D4AF37]/30 p-8 sm:p-12 shadow-2xl relative">
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
            {steps.map((st, i) => (
              <div key={i} className="p-5 rounded-2xl bg-[#131B2A] border border-slate-800 text-left space-y-2">
                <span className="w-8 h-8 rounded-lg bg-[#D4AF37]/20 border border-[#D4AF37]/40 flex items-center justify-center text-xs font-extrabold text-[#E8C872]">
                  {st.num}
                </span>
                <h4 className="text-sm font-bold text-white">{st.title}</h4>
                <p className="text-xs text-slate-400 leading-relaxed">{st.desc}</p>
              </div>
            ))}
          </div>

          {/* Área Modular para Condições Comerciais */}
          <div className="p-6 rounded-2xl bg-[#080C14] border border-slate-800 text-center mb-10 space-y-2">
            <p className="text-xs font-bold text-[#E8C872] uppercase tracking-wider">
              Condições Comerciais Personalizadas
            </p>
            <p className="text-sm text-slate-300 max-w-xl mx-auto">
              As opções de planos e condições de acesso são apresentadas individualmente pelo WhatsApp comercial, respeitando o momento e o porte do seu salão de beleza.
            </p>
          </div>

          {/* Botão de Ação Primário da Oferta */}
          <div className="text-center space-y-4">
            <a
              href={getWhatsAppUrl(WHATSAPP_MESSAGES.HAIRDRESSER)}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center gap-3 px-8 py-4 sm:py-5 rounded-2xl text-base sm:text-lg font-bold text-black bg-gradient-to-r from-[#F5E6CA] via-[#E8C872] to-[#D4AF37] hover:brightness-110 active:scale-95 transition-all shadow-xl shadow-[#D4AF37]/20"
            >
              <MessageCircle className="w-6 h-6 fill-current" />
              <span>QUERO CONTRATAR O DIAGNÓSTICO CAPILAR</span>
            </a>

            <p className="text-xs text-slate-400">
              Atendimento direto no WhatsApp: <strong className="text-slate-300">{WHATSAPP_PHONE_DISPLAY}</strong>
            </p>
          </div>

        </div>

      </div>
    </section>
  );
};
