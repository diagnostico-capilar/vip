import React, { useState } from 'react';
import { ExternalLink, MessageCircle, Smartphone, CheckCircle, FileText, ArrowRight, Eye, ShieldCheck } from 'lucide-react';
import { OFFICIAL_DIAGNOSIS_URL, WHATSAPP_MESSAGES, getWhatsAppUrl } from '../constants/links';

export const DemoPreviewSection: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'welcome' | 'questions' | 'result'>('welcome');

  return (
    <section id="demonstracao" className="py-20 lg:py-28 bg-[#080C14] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Cabeçalho */}
        <div className="max-w-3xl mx-auto text-center space-y-4 mb-16">
          <span className="text-xs font-bold text-[#D4AF37] tracking-widest uppercase">
            Transparência Total
          </span>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-white tracking-tight leading-snug">
            Antes de contratar, entenda o que sua cliente vai utilizar.
          </h2>
          <p className="text-slate-300 text-sm sm:text-base leading-relaxed">
            Veja como o questionário é organizado para ser leve, rápido e intuitivo para a sua cliente preencher no próprio celular.
          </p>
        </div>

        {/* Simulador / Demonstração da Jornada */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center max-w-5xl mx-auto">
          
          {/* Coluna de Controles / Etapas da Demonstração */}
          <div className="lg:col-span-5 space-y-4">
            <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">
              Navegue pelas etapas da jornada:
            </p>

            <button
              onClick={() => setActiveTab('welcome')}
              className={`w-full text-left p-4 rounded-xl border transition-all flex items-start gap-3.5 ${
                activeTab === 'welcome'
                  ? 'bg-[#131B2A] border-[#D4AF37] text-white shadow-md shadow-[#D4AF37]/10'
                  : 'bg-[#0E1524] border-slate-800 text-slate-400 hover:text-white hover:border-slate-700'
              }`}
            >
              <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${activeTab === 'welcome' ? 'bg-[#D4AF37] text-black font-bold' : 'bg-slate-800 text-slate-300'}`}>
                1
              </div>
              <div>
                <h4 className="text-sm font-bold text-white mb-0.5">Tela de Acolhimento</h4>
                <p className="text-xs text-slate-400 leading-snug">
                  Apresentação do diagnóstico com a identidade visual profissional do salão.
                </p>
              </div>
            </button>

            <button
              onClick={() => setActiveTab('questions')}
              className={`w-full text-left p-4 rounded-xl border transition-all flex items-start gap-3.5 ${
                activeTab === 'questions'
                  ? 'bg-[#131B2A] border-[#D4AF37] text-white shadow-md shadow-[#D4AF37]/10'
                  : 'bg-[#0E1524] border-slate-800 text-slate-400 hover:text-white hover:border-slate-700'
              }`}
            >
              <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${activeTab === 'questions' ? 'bg-[#D4AF37] text-black font-bold' : 'bg-slate-800 text-slate-300'}`}>
                2
              </div>
              <div>
                <h4 className="text-sm font-bold text-white mb-0.5">Perguntas sobre os Cabelos</h4>
                <p className="text-xs text-slate-400 leading-snug">
                  Coleta das queixas (ressecamento, químicas prévias, pontas duplas, porosidade).
                </p>
              </div>
            </button>

            <button
              onClick={() => setActiveTab('result')}
              className={`w-full text-left p-4 rounded-xl border transition-all flex items-start gap-3.5 ${
                activeTab === 'result'
                  ? 'bg-[#131B2A] border-[#D4AF37] text-white shadow-md shadow-[#D4AF37]/10'
                  : 'bg-[#0E1524] border-slate-800 text-slate-400 hover:text-white hover:border-slate-700'
              }`}
            >
              <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${activeTab === 'result' ? 'bg-[#D4AF37] text-black font-bold' : 'bg-slate-800 text-slate-300'}`}>
                3
              </div>
              <div>
                <h4 className="text-sm font-bold text-white mb-0.5">Envio para o Profissional</h4>
                <p className="text-xs text-slate-400 leading-snug">
                  As respostas chegam estruturadas no WhatsApp para apoiar a recomendação.
                </p>
              </div>
            </button>

            {/* Acesso ao questionário oficial */}
            <div className="pt-4 border-t border-slate-800/80 space-y-3">
              <a
                href={OFFICIAL_DIAGNOSIS_URL}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full flex items-center justify-center gap-2 px-5 py-3 rounded-xl text-xs sm:text-sm font-semibold text-slate-200 bg-[#141C2E] hover:bg-[#1A253C] border border-slate-700 transition-colors"
              >
                <Eye className="w-4 h-4 text-[#D4AF37]" />
                <span>Testar o Questionário Oficial da MF</span>
                <ExternalLink className="w-3.5 h-3.5 text-slate-400" />
              </a>
              <p className="text-[11px] text-slate-400 leading-tight">
                * O link acima abre o sistema oficial em produção para você experimentar a visão da cliente. A contratação do plano para o seu salão é realizada com nossa equipe.
              </p>
            </div>
          </div>

          {/* Coluna Visual: Mockup de Celular Reativo à Aba Selecionada */}
          <div className="lg:col-span-7 flex justify-center">
            <div className="w-full max-w-sm rounded-[36px] bg-[#0A0E17] border-[4px] border-slate-800 p-4 shadow-2xl shadow-[#D4AF37]/10 text-left">
              
              {/* Notch */}
              <div className="w-20 h-3.5 bg-slate-800 rounded-full mx-auto mb-4" />

              {/* Conteúdo Dinâmico da Tela */}
              <div className="rounded-[24px] bg-[#0E1524] p-5 border border-slate-800 min-h-[380px] flex flex-col justify-between">
                
                {activeTab === 'welcome' && (
                  <div className="space-y-4">
                    <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#D4AF37] to-[#996515] flex items-center justify-center font-bold text-black text-sm">
                      MF
                    </div>
                    <div>
                      <span className="text-[11px] font-semibold text-[#D4AF37] uppercase tracking-wider">
                        Atendimento Personalizado
                      </span>
                      <h4 className="text-lg font-bold text-white mt-1">
                        Diagnóstico Capilar Profissional
                      </h4>
                      <p className="text-xs text-slate-300 mt-2 leading-relaxed">
                        Olá! Queremos entender as necessidades dos seus fios para que sua cabeleireira prepare o cuidado ideal para o seu cabelo.
                      </p>
                    </div>

                    <div className="p-3 rounded-xl bg-[#131B2A] border border-slate-800 text-xs text-slate-300 space-y-1.5">
                      <div className="flex items-center gap-1.5 text-white font-medium">
                        <CheckCircle className="w-3.5 h-3.5 text-[#D4AF37]" />
                        <span>Rápido: leva menos de 2 minutos</span>
                      </div>
                      <div className="flex items-center gap-1.5 text-white font-medium">
                        <CheckCircle className="w-3.5 h-3.5 text-[#D4AF37]" />
                        <span>Respostas enviadas direto à sua profissional</span>
                      </div>
                    </div>

                    <div className="pt-2">
                      <div className="w-full py-2.5 rounded-lg bg-[#D4AF37] text-black text-xs font-bold text-center">
                        Iniciar Meu Diagnóstico
                      </div>
                    </div>
                  </div>
                )}

                {activeTab === 'questions' && (
                  <div className="space-y-4">
                    <div className="flex items-center justify-between text-xs pb-2 border-b border-slate-800">
                      <span className="text-[#D4AF37] font-semibold">Etapa de Avaliação</span>
                      <span className="text-slate-400">Questão 3</span>
                    </div>

                    <p className="text-sm font-bold text-white">
                      Seu cabelo passou recentemente por processos químicos?
                    </p>

                    <div className="space-y-2 text-xs">
                      <div className="p-2.5 rounded-lg bg-[#D4AF37]/15 border border-[#D4AF37]/50 text-white flex items-center justify-between">
                        <span>Descoloração / Mechas / Luzes</span>
                        <CheckCircle className="w-4 h-4 text-[#D4AF37]" />
                      </div>
                      <div className="p-2.5 rounded-lg bg-[#141C2E] border border-slate-800 text-slate-300">
                        <span>Progressiva / Alisamento térmico</span>
                      </div>
                      <div className="p-2.5 rounded-lg bg-[#141C2E] border border-slate-800 text-slate-300">
                        <span>Coloração ou tonalizante</span>
                      </div>
                      <div className="p-2.5 rounded-lg bg-[#141C2E] border border-slate-800 text-slate-300">
                        <span>Sem química recente</span>
                      </div>
                    </div>

                    <div className="w-full py-2 rounded-lg bg-slate-800 text-slate-400 text-xs font-medium text-center">
                      Próxima Pergunta →
                    </div>
                  </div>
                )}

                {activeTab === 'result' && (
                  <div className="space-y-3">
                    <div className="flex items-center gap-2 text-emerald-400 text-xs font-bold">
                      <MessageCircle className="w-4 h-4 fill-current" />
                      <span>Mensagem Entregue no WhatsApp</span>
                    </div>

                    <div className="p-3.5 rounded-xl bg-[#091D17] border border-emerald-600/30 text-xs text-emerald-100 space-y-2">
                      <p className="font-bold text-emerald-300 border-b border-emerald-800/40 pb-1">
                        📋 Resumo do Diagnóstico Capilar
                      </p>
                      <p><strong>Cliente:</strong> Juliana Castro</p>
                      <p><strong>Queixa Principal:</strong> Ressecamento intenso e quebra</p>
                      <p><strong>Histórico:</strong> Mechas realizadas há 40 dias</p>
                      <p><strong>Cuidados em casa:</strong> Usa shampoo comum de supermercado</p>
                      <div className="p-2 rounded bg-emerald-950/60 border border-emerald-800/40 text-[11px] text-emerald-200">
                        💡 <em>Oportunidade para você:</em> Agendar sessão de Reconstrução Lipídica e sugerir linha home care de nutrição profunda.
                      </div>
                    </div>

                    <p className="text-[10px] text-slate-400 text-center leading-tight">
                      Pronto para iniciar a conversa com argumentos técnicos e claros!
                    </p>
                  </div>
                )}

                {/* Rodapé interno da tela */}
                <div className="pt-3 border-t border-slate-800 text-center text-[10px] text-slate-400">
                  MF Cosméticos Profissionais · Diagnóstico Capilar
                </div>
              </div>

            </div>
          </div>

        </div>

        {/* Botão Comercial Secundário */}
        <div className="mt-14 text-center">
          <a
            href={getWhatsAppUrl(WHATSAPP_MESSAGES.DEMO)}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-7 py-3.5 rounded-xl text-sm font-bold text-white bg-[#141C2E] hover:bg-[#1C273F] border border-[#D4AF37]/50 transition-all shadow-md"
          >
            <MessageCircle className="w-4 h-4 text-[#D4AF37] fill-current" />
            <span>QUERO SABER COMO FUNCIONA (CONVERSAR NO WHATSAPP)</span>
          </a>
        </div>

      </div>
    </section>
  );
};
