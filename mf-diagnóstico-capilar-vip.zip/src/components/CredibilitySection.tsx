import React from 'react';
import { ShieldCheck, Phone, CheckCircle2, Building2, Users2, Sparkles } from 'lucide-react';
import { COMPANY_NAME, COMPANY_EXPERIENCE, WHATSAPP_PHONE_DISPLAY, WHATSAPP_MESSAGES, getWhatsAppUrl } from '../constants/links';

export const CredibilitySection: React.FC = () => {
  return (
    <section className="py-20 lg:py-28 bg-[#0B0F17] border-y border-slate-800/80 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Coluna Institucional */}
          <div className="lg:col-span-7 space-y-6 text-left">
            <span className="text-xs font-bold text-[#D4AF37] tracking-widest uppercase">
              Credibilidade e Tradição
            </span>

            <h2 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-white tracking-tight leading-snug">
              Conheça a empresa por trás da solução.
            </h2>

            <div className="inline-block p-4 rounded-xl bg-[#131B2A] border border-[#D4AF37]/40">
              <p className="text-base sm:text-lg font-bold text-[#F5E6CA] flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-[#D4AF37]" />
                <span>{COMPANY_EXPERIENCE}</span>
              </p>
            </div>

            <p className="text-slate-300 text-sm sm:text-base leading-relaxed">
              A <strong className="text-white">{COMPANY_NAME}</strong> atua lado a lado com os cabeleireiros brasileiros, fornecendo cosméticos profissionais de alta performance e entendendo as demandas reais do dia a dia do salão.
            </p>

            <p className="text-slate-400 text-xs sm:text-sm leading-relaxed">
              * Nota de transparência: Os mais de 32 anos de experiência referem-se à trajetória institucional consolidada da MF Cosméticos Profissionais no mercado de beleza profissional, e não ao tempo de existência desta ferramenta de diagnóstico digital.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              <div className="p-4 rounded-xl bg-[#0E1524] border border-slate-800 flex items-start gap-3">
                <ShieldCheck className="w-5 h-5 text-[#D4AF37] shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-xs font-bold text-white uppercase tracking-wider">Compromisso Ético</h4>
                  <p className="text-xs text-slate-400 mt-1 leading-snug">
                    Ferramentas desenvolvidas com respeito ao papel técnico do profissional e sem falsas promessas.
                  </p>
                </div>
              </div>

              <div className="p-4 rounded-xl bg-[#0E1524] border border-slate-800 flex items-start gap-3">
                <Users2 className="w-5 h-5 text-[#D4AF37] shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-xs font-bold text-white uppercase tracking-wider">Suporte Próximo</h4>
                  <p className="text-xs text-slate-400 mt-1 leading-snug">
                    Atendimento comercial e técnico humanizado diretamente via WhatsApp.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Coluna Contato Oficial */}
          <div className="lg:col-span-5">
            <div className="rounded-3xl bg-gradient-to-b from-[#131B2A] to-[#0E1524] border border-slate-700/80 p-8 text-center space-y-6 shadow-xl">
              
              <div className="w-16 h-16 rounded-2xl bg-[#D4AF37]/15 border border-[#D4AF37]/30 flex items-center justify-center mx-auto text-[#D4AF37]">
                <Building2 className="w-8 h-8" />
              </div>

              <div>
                <h3 className="text-xl font-bold text-white">Canal Oficial de Atendimento</h3>
                <p className="text-xs text-slate-400 mt-1">
                  MF Cosméticos Profissionais
                </p>
              </div>

              <div className="p-4 rounded-xl bg-[#080C14] border border-slate-800 text-left space-y-2">
                <div className="flex items-center gap-2 text-xs text-slate-400">
                  <Phone className="w-4 h-4 text-[#D4AF37]" />
                  <span>WhatsApp Comercial:</span>
                </div>
                <p className="text-lg font-bold text-[#E8C872] pl-6 tracking-wide">
                  {WHATSAPP_PHONE_DISPLAY}
                </p>
              </div>

              <a
                href={getWhatsAppUrl(WHATSAPP_MESSAGES.HAIRDRESSER)}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-3.5 px-4 rounded-xl text-sm font-bold text-black bg-gradient-to-r from-[#F5E6CA] via-[#E8C872] to-[#D4AF37] hover:brightness-110 active:scale-95 transition-all shadow-md flex items-center justify-center gap-2"
              >
                <span>Conversar com a Equipe MF</span>
              </a>

              <p className="text-[11px] text-slate-400 leading-tight">
                Tire dúvidas sobre o sistema, ativação para o seu salão e condições comerciais sem compromisso.
              </p>

            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
