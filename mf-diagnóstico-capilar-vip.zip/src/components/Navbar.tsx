import React, { useState } from 'react';
import { MessageCircle, Menu, X, Sparkles } from 'lucide-react';
import { COMPANY_NAME, WHATSAPP_MESSAGES, getWhatsAppUrl } from '../constants/links';

export const Navbar: React.FC = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 bg-[#080C14]/90 backdrop-blur-md border-b border-slate-800/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between gap-8">
        {/* Zone 1: Brand wordmark (single line, no clutter) */}
        <a href="#" className="flex items-center gap-3 whitespace-nowrap shrink-0 text-left">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#D4AF37] to-[#996515] p-0.5 shadow-md shadow-[#D4AF37]/10 flex items-center justify-center">
            <div className="w-full h-full bg-[#0B0F17] rounded-[10px] flex items-center justify-center">
              <span className="text-sm font-black text-[#D4AF37] tracking-wider">MF</span>
            </div>
          </div>
          <div className="flex flex-col">
            <span className="text-base sm:text-lg font-bold text-white tracking-tight flex items-center gap-1.5">
              MF Diagnóstico Capilar
            </span>
            <span className="text-[11px] text-[#D4AF37] tracking-wider uppercase font-semibold">
              Cosméticos Profissionais
            </span>
          </div>
        </a>

        {/* Zone 2: Navigation Links (4-5 items, clean single line) */}
        <nav className="hidden lg:flex items-center gap-8 text-sm font-medium text-slate-300">
          <a href="#como-funciona" className="hover:text-[#D4AF37] transition-colors whitespace-nowrap shrink-0">
            Como Funciona
          </a>
          <a href="#demonstracao" className="hover:text-[#D4AF37] transition-colors whitespace-nowrap shrink-0">
            Demonstração
          </a>
          <a href="#beneficios" className="hover:text-[#D4AF37] transition-colors whitespace-nowrap shrink-0">
            Benefícios
          </a>
          <a href="#simulacao" className="hover:text-[#D4AF37] transition-colors whitespace-nowrap shrink-0">
            Simulador
          </a>
          <a href="#faq" className="hover:text-[#D4AF37] transition-colors whitespace-nowrap shrink-0">
            Dúvidas
          </a>
        </nav>

        {/* Zone 3: 1 Primary CTA Button */}
        <div className="hidden sm:flex items-center gap-4 shrink-0">
          <a
            href={getWhatsAppUrl(WHATSAPP_MESSAGES.HAIRDRESSER)}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs sm:text-sm font-semibold text-[#080C14] bg-gradient-to-r from-[#F5E6CA] via-[#E8C872] to-[#D4AF37] hover:brightness-110 active:scale-95 transition-all shadow-md shadow-[#D4AF37]/20 whitespace-nowrap shrink-0"
          >
            <MessageCircle className="w-4 h-4 fill-current" />
            <span>Falar no WhatsApp</span>
          </a>
        </div>

        {/* Mobile menu toggle */}
        <div className="flex sm:hidden items-center">
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            aria-label="Abrir menu de navegação"
            className="p-2 text-slate-300 hover:text-white rounded-lg focus:outline-none"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="sm:hidden px-4 pt-3 pb-6 border-b border-slate-800 bg-[#0B0F17] space-y-3">
          <a
            href="#como-funciona"
            onClick={() => setMobileMenuOpen(false)}
            className="block px-3 py-2 text-base font-medium text-slate-300 hover:text-[#D4AF37] hover:bg-slate-900 rounded-lg"
          >
            Como Funciona
          </a>
          <a
            href="#demonstracao"
            onClick={() => setMobileMenuOpen(false)}
            className="block px-3 py-2 text-base font-medium text-slate-300 hover:text-[#D4AF37] hover:bg-slate-900 rounded-lg"
          >
            Demonstração
          </a>
          <a
            href="#beneficios"
            onClick={() => setMobileMenuOpen(false)}
            className="block px-3 py-2 text-base font-medium text-slate-300 hover:text-[#D4AF37] hover:bg-slate-900 rounded-lg"
          >
            Benefícios para Cabeleireiros
          </a>
          <a
            href="#simulacao"
            onClick={() => setMobileMenuOpen(false)}
            className="block px-3 py-2 text-base font-medium text-slate-300 hover:text-[#D4AF37] hover:bg-slate-900 rounded-lg"
          >
            Simulador de Retorno
          </a>
          <a
            href="#faq"
            onClick={() => setMobileMenuOpen(false)}
            className="block px-3 py-2 text-base font-medium text-slate-300 hover:text-[#D4AF37] hover:bg-slate-900 rounded-lg"
          >
            Perguntas Frequentes
          </a>
          <div className="pt-2">
            <a
              href={getWhatsAppUrl(WHATSAPP_MESSAGES.HAIRDRESSER)}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-2 w-full py-3 px-4 rounded-xl text-sm font-semibold text-[#080C14] bg-gradient-to-r from-[#F5E6CA] via-[#E8C872] to-[#D4AF37]"
            >
              <MessageCircle className="w-4 h-4 fill-current" />
              <span>Falar no WhatsApp Comercial</span>
            </a>
          </div>
        </div>
      )}
    </header>
  );
};
