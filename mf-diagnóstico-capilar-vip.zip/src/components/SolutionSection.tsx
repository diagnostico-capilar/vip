import React from 'react';
import { UserCheck, MessageSquareHeart, TrendingUp, Sparkles, Check } from 'lucide-react';

export const SolutionSection: React.FC = () => {
  const pillars = [
    {
      number: '01',
      icon: UserCheck,
      title: 'Conheça melhor a cliente',
      description: 'Obtenha informações organizadas sobre as condições dos cabelos, histórico de procedimentos e queixas relatadas no questionário.',
      details: [
        'Identificação de químicas recentes e histórico dos fios',
        'Grau percebido de ressecamento, frizz ou oleosidade',
        'Hábitos de lavagem e cuidados diários em casa',
      ],
    },
    {
      number: '02',
      icon: MessageSquareHeart,
      title: 'Personalize a conversa',
      description: 'Utilize as respostas para orientar a avaliação presencial e explicar com clareza técnica as possibilidades de tratamento.',
      details: [
        'Consulta baseada nas queixas relatadas pela própria cliente',
        'Explicação transparente da necessidade de cada etapa',
        'Mais segurança e autoridade técnica na cadeira',
      ],
    },
    {
      number: '03',
      icon: TrendingUp,
      title: 'Crie oportunidades comerciais',
      description: 'Apresente serviços e cuidados pertinentes às necessidades da cliente, sem depender apenas de uma venda pontual ou insistente.',
      details: [
        'Proposta de cronogramas capilares personalizados',
        'Recomendação ética de produtos de manutenção home care',
        'Fidelização contínua e retorno planejado ao salão',
      ],
    },
  ];

  return (
    <section className="py-20 lg:py-28 bg-[#080C14] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Cabeçalho */}
        <div className="max-w-3xl mx-auto text-center space-y-4 mb-16">
          <span className="text-xs font-bold text-[#D4AF37] tracking-widest uppercase">
            A Solução MF Cosméticos
          </span>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-white tracking-tight leading-snug">
            Apresente uma nova experiência de atendimento no seu salão.
          </h2>
          <p className="text-slate-300 text-sm sm:text-base leading-relaxed">
            O <strong className="text-white">MF Diagnóstico Capilar</strong> oferece uma maneira prática de coletar informações sobre as necessidades capilares da cliente antes de conversar sobre os cuidados que ela precisa.
          </p>
          <p className="text-slate-400 text-sm leading-relaxed max-w-2xl mx-auto">
            Com essas informações, o profissional pode organizar melhor o atendimento, explicar suas recomendações e apresentar opções de tratamentos e produtos compatíveis com as necessidades identificadas.
          </p>
        </div>

        {/* 3 Pilares Principais */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {pillars.map((pillar, idx) => {
            const IconComponent = pillar.icon;
            return (
              <div
                key={idx}
                className="relative rounded-2xl bg-[#0E1524] border border-slate-800/90 p-8 hover:border-[#D4AF37]/40 transition-all duration-300 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-6">
                    <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#D4AF37]/20 to-[#996515]/10 border border-[#D4AF37]/30 flex items-center justify-center text-[#E8C872]">
                      <IconComponent className="w-6 h-6" />
                    </div>
                    <span className="text-2xl font-black text-slate-700 select-none">
                      {pillar.number}
                    </span>
                  </div>

                  <h3 className="text-xl font-bold text-white mb-3">
                    {pillar.title}
                  </h3>

                  <p className="text-slate-400 text-sm leading-relaxed mb-6">
                    {pillar.description}
                  </p>
                </div>

                <div className="pt-6 border-t border-slate-800/80 space-y-2.5">
                  {pillar.details.map((detail, dIdx) => (
                    <div key={dIdx} className="flex items-start gap-2 text-xs text-slate-300">
                      <Check className="w-4 h-4 text-[#D4AF37] shrink-0 mt-0.5" />
                      <span>{detail}</span>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
