import React from 'react';
import { MessageCircle, Sparkles, CheckCircle2 } from 'lucide-react';
import { COMPANY_NAME, COMPANY_EXPERIENCE, WHATSAPP_MESSAGES, getWhatsAppUrl, WHATSAPP_PHONE_DISPLAY } from '../constants/links';

export const FinalCtaSection: React.FC = () => {
  return (
    <section className="py-20 lg:py-28 bg-[#080C14] relative overflow-hidden">
      {/* Luzes de fundo */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full max-w-4xl h-80 bg-radial-gold pointer-events-none" />

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
        
        <div className="rounded-3xl bg-gradient-to-b from-[#131B2A] to-[#0E1524] border border-[#D4AF37]/40 p-8 sm:p-14 shadow-2xl space-y-8">
          
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#1A2438] border border-[#D4AF37]/30 text-xs font-semibold text-[#E8C872]">
            <Sparkles className="w-3.5 h-3.5 text-[#D4AF37]" />
            <span>{COMPANY_NAME}</span>
          </div>

          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-white tracking-tight leading-snug max-w-3xl mx-auto">
            Seu próximo passo pode ser oferecer uma experiência mais personalizada às suas clientes.
          </h2>

          <p className="text-slate-300 text-sm sm:text-base leading-relaxed max-w-2xl mx-auto">
            Conheça o <strong className="text-white">MF Diagnóstico Capilar</strong> e veja como utilizar as informações do diagnóstico para orientar conversas, apresentar tratamentos e fortalecer o relacionamento com suas clientes.
          </p>

          <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-4">
            <a
              href={getWhatsAppUrl(WHATSAPP_MESSAGES.HAIRDRESSER)}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center gap-3 px-8 py-4 sm:py-5 rounded-2xl text-base sm:text-lg font-bold text-black bg-gradient-to-r from-[#F5E6CA] via-[#E8C872] to-[#D4AF37] hover:brightness-110 active:scale-95 transition-all shadow-xl shadow-[#D4AF37]/20 whitespace-nowrap"
            >
              <MessageCircle className="w-6 h-6 fill-current" />
              <span>QUERO CONHECER O MF DIAGNÓSTICO CAPILAR</span>
            </a>
          </div>

          <div className="pt-4 flex flex-wrap items-center justify-center gap-6 text-xs text-slate-400">
            <div className="flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-[#D4AF37]" />
              <span>{COMPANY_EXPERIENCE}</span>
            </div>
            <div className="flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-[#D4AF37]" />
              <span>Atendimento direto pelo WhatsApp: {WHATSAPP_PHONE_DISPLAY}</span>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
