import React from 'react';
import { MessageCircle } from 'lucide-react';
import { WHATSAPP_MESSAGES, getWhatsAppUrl } from '../constants/links';

export const FloatingWhatsapp: React.FC = () => {
  return (
    <aside 
      aria-label="Atendimento rápido no WhatsApp"
      className="fixed bottom-5 right-5 z-40 flex items-center group pointer-events-auto"
    >
      <a
        href={getWhatsAppUrl(WHATSAPP_MESSAGES.HAIRDRESSER)}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Abrir conversa no WhatsApp Comercial"
        className="flex items-center gap-2.5 px-4 py-3 rounded-full bg-[#25D366] text-white font-bold shadow-2xl hover:scale-105 active:scale-95 transition-all duration-200 border-2 border-emerald-400/40"
      >
        <MessageCircle className="w-6 h-6 fill-current shrink-0" />
        <span className="hidden sm:inline text-xs font-bold text-white tracking-wide">
          Dúvidas? Fale no WhatsApp
        </span>
      </a>
    </aside>
  );
};
