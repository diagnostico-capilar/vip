import React, { useState } from 'react';
import { Calculator, AlertTriangle, Info, Sparkles, TrendingUp, HelpCircle } from 'lucide-react';

export const RoiCalculatorSection: React.FC = () => {
  // Valores padrão baseados no exemplo matemático do briefing oficial
  const [treatmentsCount, setTreatmentsCount] = useState<number>(4);
  const [marginPerTreatment, setMarginPerTreatment] = useState<number>(80);

  const totalContribution = treatmentsCount * marginPerTreatment;

  return (
    <section id="simulacao" className="py-20 lg:py-28 bg-[#080C14] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Cabeçalho */}
        <div className="max-w-3xl mx-auto text-center space-y-4 mb-16">
          <span className="text-xs font-bold text-[#D4AF37] tracking-widest uppercase">
            Análise de Viabilidade
          </span>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-white tracking-tight leading-snug">
            Uma ferramenta comercial precisa fazer sentido para o seu negócio.
          </h2>
          <p className="text-slate-300 text-sm sm:text-base leading-relaxed">
            O retorno do investimento em qualquer recurso profissional depende da sua frequência de uso, da qualidade técnica da conversa, da procura real por serviços no salão e das margens praticadas.
          </p>
        </div>

        {/* Simulador Interativo */}
        <div className="max-w-4xl mx-auto bg-[#0E1524] border border-slate-800/90 rounded-3xl p-6 sm:p-10 shadow-2xl relative">
          
          <div className="flex items-center gap-3 pb-6 border-b border-slate-800">
            <div className="w-10 h-10 rounded-xl bg-[#D4AF37]/15 border border-[#D4AF37]/30 flex items-center justify-center text-[#D4AF37]">
              <Calculator className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white">
                Simulador Matemático Ilustrativo
              </h3>
              <p className="text-xs text-slate-400">
                Ajuste os valores para visualizar a margem de contribuição hipotética
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 my-8 items-center">
            
            {/* Controles Sliders */}
            <div className="space-y-6 text-left">
              
              {/* Controle 1: Tratamentos Adicionais */}
              <div className="space-y-2">
                <div className="flex justify-between items-center text-sm">
                  <label htmlFor="treatments-slider" className="font-semibold text-slate-200">
                    Tratamentos adicionais no mês:
                  </label>
                  <span className="text-base font-extrabold text-[#E8C872] tabular-nums bg-[#131B2A] px-3 py-1 rounded-lg border border-slate-700">
                    {treatmentsCount} {treatmentsCount === 1 ? 'tratamento' : 'tratamentos'}
                  </span>
                </div>
                <input
                  id="treatments-slider"
                  type="range"
                  min="1"
                  max="20"
                  step="1"
                  value={treatmentsCount}
                  onChange={(e) => setTreatmentsCount(Number(e.target.value))}
                  className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-[#D4AF37]"
                />
                <div className="flex justify-between text-[11px] text-slate-400">
                  <span>1 atendimento</span>
                  <span className="text-[#D4AF37] font-medium">Padrão do exemplo: 4</span>
                  <span>20 atendimentos</span>
                </div>
              </div>

              {/* Controle 2: Margem por Tratamento */}
              <div className="space-y-2">
                <div className="flex justify-between items-center text-sm">
                  <label htmlFor="margin-slider" className="font-semibold text-slate-200">
                    Margem de contribuição por tratamento:
                  </label>
                  <span className="text-base font-extrabold text-[#E8C872] tabular-nums bg-[#131B2A] px-3 py-1 rounded-lg border border-slate-700">
                    R$ {marginPerTreatment}
                  </span>
                </div>
                <input
                  id="margin-slider"
                  type="range"
                  min="40"
                  max="250"
                  step="10"
                  value={marginPerTreatment}
                  onChange={(e) => setMarginPerTreatment(Number(e.target.value))}
                  className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-[#D4AF37]"
                />
                <div className="flex justify-between text-[11px] text-slate-400">
                  <span>R$ 40</span>
                  <span className="text-[#D4AF37] font-medium">Padrão do exemplo: R$ 80</span>
                  <span>R$ 250</span>
                </div>
              </div>

            </div>

            {/* Resultado do Cálculo */}
            <div className="p-6 rounded-2xl bg-gradient-to-br from-[#131B2A] to-[#162136] border border-[#D4AF37]/40 text-center flex flex-col justify-center space-y-3">
              <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
                Margem de Contribuição Adicional Simulada
              </span>
              
              <div className="text-3xl sm:text-4xl font-black text-white tabular-nums tracking-tight">
                R$ <span className="text-[#E8C872]">{totalContribution.toLocaleString('pt-BR')}</span>
              </div>

              <div className="text-xs text-slate-300 font-mono bg-black/30 py-2 px-3 rounded-lg">
                {treatmentsCount} {treatmentsCount === 1 ? 'tratamento' : 'tratamentos'} × R$ {marginPerTreatment} = R$ {totalContribution}
              </div>

              <p className="text-[11px] text-slate-400 leading-tight">
                Valor bruto da margem adicional calculada antes de descontar o custo da ferramenta e despesas não consideradas.
              </p>
            </div>

          </div>

          {/* Observação e Advertência Obrigatória do Briefing */}
          <div className="p-5 rounded-2xl bg-[#1C1610] border border-[#D4AF37]/30 text-left flex items-start gap-3.5">
            <AlertTriangle className="w-5 h-5 text-[#E8C872] shrink-0 mt-0.5" />
            <div className="space-y-1">
              <h4 className="text-xs font-bold text-[#E8C872] uppercase tracking-wider">
                Aviso Legal e Regra de Transparência
              </h4>
              <p className="text-xs text-slate-300 leading-relaxed">
                <strong>Este é apenas um exemplo matemático para demonstrar como avaliar a viabilidade da ferramenta. Não representa uma previsão ou garantia de vendas ou resultados financeiros.</strong>
              </p>
              <p className="text-[11px] text-slate-400 leading-relaxed">
                O sucesso comercial depende exclusivamente da dedicação do profissional, da sua base de clientes, dos preços praticados no seu salão e da consistência de uso do diagnóstico.
              </p>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
