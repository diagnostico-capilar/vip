import React from 'react';
import { Share2, Smartphone, MessageSquareCode, Sparkles, HeartHandshake, CheckCircle2 } from 'lucide-react';

export const HowItWorksSection: React.FC = () => {
  const steps = [
    {
      step: '01',
      icon: Share2,
      title: 'Compartilhe o link',
      description: 'O cabeleireiro compartilha o link exclusivo do diagnóstico com a cliente pelo WhatsApp, direct do Instagram ou bio das redes sociais.',
      tag: 'Prático e Rápido',
    },
    {
      step: '02',
      icon: Smartphone,
      title: 'A cliente responde',
      description: 'A cliente acessa o questionário online pelo celular em poucos minutos e responde às perguntas sobre os hábitos e necessidades dos cabelos.',
      tag: 'Sem Baixar App',
    },
    {
      step: '03',
      icon: MessageSquareCode,
      title: 'O profissional recebe as respostas',
      description: 'Após a contratação do serviço e o cadastro do WhatsApp da cabeleireira, as respostas são encaminhadas diretamente para o número cadastrado.',
      tag: 'WhatsApp Cadastrado',
    },
    {
      step: '04',
      icon: Sparkles,
      title: 'Oriente o tratamento',
      description: 'O profissional utiliza as informações recebidas como apoio técnico para avaliar a situação, conversar com a cliente e recomendar tratamentos e produtos adequados.',
      tag: 'Atendimento Consultivo',
    },
    {
      step: '05',
      icon: HeartHandshake,
      title: 'Mantenha o relacionamento',
      description: 'O cabeleireiro utiliza o canal de conversa para acompanhar a evolução dos fios e planejar as próximas visitas e manutenções no salão.',
      tag: 'Fidelização Contínua',
    },
  ];

  return (
    <section id="como-funciona" className="py-20 lg:py-28 bg-[#0B0F17] border-y border-slate-800/80 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Cabeçalho */}
        <div className="max-w-3xl mx-auto text-center space-y-4 mb-16">
          <span className="text-xs font-bold text-[#D4AF37] tracking-widest uppercase">
            Passo a Passo Descomplicado
          </span>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-white tracking-tight leading-snug">
            Veja como o diagnóstico pode fazer parte da rotina do seu salão.
          </h2>
          <p className="text-slate-400 text-sm sm:text-base leading-relaxed">
            Uma dinâmica simples e sem atrito para você e suas clientes, integrando o ambiente digital ao atendimento presencial.
          </p>
        </div>

        {/* 5 Etapas em Linha do Tempo Visual */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
          {steps.map((item, index) => {
            const IconComponent = item.icon;
            return (
              <div
                key={index}
                className="relative rounded-2xl bg-[#0E1524] border border-slate-800/90 p-6 flex flex-col justify-between hover:border-[#D4AF37]/40 transition-all group"
              >
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-xs font-bold text-[#D4AF37] bg-[#D4AF37]/10 px-2.5 py-1 rounded-full">
                      Etapa {item.step}
                    </span>
                    <span className="text-[11px] font-medium text-slate-400">
                      {item.tag}
                    </span>
                  </div>

                  <div className="w-12 h-12 rounded-xl bg-[#141C2E] border border-slate-800 flex items-center justify-center text-[#E8C872] group-hover:bg-[#D4AF37] group-hover:text-black transition-all mb-4">
                    <IconComponent className="w-6 h-6" />
                  </div>

                  <h3 className="text-base font-bold text-white mb-2 leading-snug">
                    {item.title}
                  </h3>

                  <p className="text-slate-400 text-xs sm:text-sm leading-relaxed">
                    {item.description}
                  </p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Nota técnica de transparência operacional */}
        <div className="mt-12 p-4 sm:p-5 rounded-xl bg-[#0E1524]/70 border border-slate-800 text-xs text-slate-400 max-w-3xl mx-auto flex items-center gap-3">
          <CheckCircle2 className="w-5 h-5 text-[#D4AF37] shrink-0" />
          <span>
            <strong>Informação importante:</strong> No funcionamento do serviço, o número de WhatsApp da cabeleireira é vinculado no sistema após a contratação para garantir que todas as respostas das clientes sejam entregues com segurança ao salão correto.
          </span>
        </div>

      </div>
    </section>
  );
};
