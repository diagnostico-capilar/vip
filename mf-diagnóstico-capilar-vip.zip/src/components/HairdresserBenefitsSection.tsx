import React from 'react';
import { Award, Sparkles, BookOpenCheck, Compass, Share2, RefreshCw, Quote } from 'lucide-react';

export const HairdresserBenefitsSection: React.FC = () => {
  const benefits = [
    {
      icon: BookOpenCheck,
      title: 'Conhecer melhor as necessidades relatadas',
      description: 'Tenha em mãos as principais queixas e hábitos que a cliente informou antes mesmo de iniciar o atendimento no salão.',
    },
    {
      icon: Compass,
      title: 'Apoiar a indicação de tratamentos adequados',
      description: 'Tenha embasamento técnico para sugerir hidratações, nutrições ou reconstruções compatíveis com a realidade dos fios.',
    },
    {
      icon: Award,
      title: 'Explicar de maneira mais clara o valor dos serviços',
      description: 'Demonstre profissionalismo e consultoria especializada, saindo da postura de quem apenas executa para quem cuida da saúde capilar.',
    },
    {
      icon: Sparkles,
      title: 'Diferenciar o atendimento do salão',
      description: 'Ofereça uma experiência moderna e digital que poucos salões da sua região proporcionam às clientes.',
    },
    {
      icon: Share2,
      title: 'Facilidade para compartilhar o recurso',
      description: 'Basta enviar o link pelo WhatsApp ou disponibilizar na bio do Instagram para qualquer cliente acessar pelo navegador.',
    },
    {
      icon: RefreshCw,
      title: 'Novas oportunidades de relacionamento e retorno',
      description: 'Crie motivos legítimos para conversar com a cliente entre as visitas, mantendo a proximidade e o acompanhamento dos resultados.',
    },
  ];

  return (
    <section id="beneficios" className="py-20 lg:py-28 bg-[#0B0F17] border-y border-slate-800/80 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Cabeçalho */}
        <div className="max-w-3xl mx-auto text-center space-y-4 mb-16">
          <span className="text-xs font-bold text-[#D4AF37] tracking-widest uppercase">
            Valor para o Seu Salão
          </span>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-white tracking-tight leading-snug">
            Mais informações para orientar. Mais oportunidades para valorizar seu atendimento.
          </h2>
          <p className="text-slate-400 text-sm sm:text-base leading-relaxed">
            Como o diagnóstico apoia o dia a dia da cabeleireira e fortalece a percepção de autoridade profissional.
          </p>
        </div>

        {/* Grade de Benefícios */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
          {benefits.map((item, idx) => {
            const IconComponent = item.icon;
            return (
              <div
                key={idx}
                className="p-6 rounded-2xl bg-[#0E1524] border border-slate-800/90 hover:border-[#D4AF37]/40 transition-all flex flex-col justify-between group"
              >
                <div className="space-y-4">
                  <div className="w-12 h-12 rounded-xl bg-[#141C2E] border border-slate-800 flex items-center justify-center text-[#E8C872] group-hover:bg-[#D4AF37]/15 group-hover:text-[#D4AF37] transition-colors">
                    <IconComponent className="w-6 h-6" />
                  </div>
                  <h3 className="text-lg font-bold text-white group-hover:text-[#F5E6CA] transition-colors leading-snug">
                    {item.title}
                  </h3>
                  <p className="text-slate-400 text-sm leading-relaxed">
                    {item.description}
                  </p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Frase de Destaque Obrigatória do Briefing */}
        <div className="max-w-4xl mx-auto rounded-3xl bg-gradient-to-r from-[#121927] via-[#1A2338] to-[#121927] border border-[#D4AF37]/40 p-8 sm:p-10 relative overflow-hidden shadow-xl">
          <Quote className="absolute -top-3 -right-3 w-28 h-28 text-[#D4AF37]/10 pointer-events-none" />
          
          <div className="relative z-10 flex flex-col items-center text-center space-y-4">
            <div className="w-10 h-10 rounded-full bg-[#D4AF37]/20 border border-[#D4AF37]/40 flex items-center justify-center text-[#D4AF37]">
              <Sparkles className="w-5 h-5" />
            </div>

            <blockquote className="text-lg sm:text-2xl font-bold text-white tracking-tight leading-relaxed max-w-3xl">
              &ldquo;Não se trata apenas de oferecer um tratamento. Trata-se de entender a necessidade da cliente e explicar por que determinada solução pode fazer sentido para ela.&rdquo;
            </blockquote>

            <p className="text-xs uppercase tracking-widest text-[#D4AF37] font-semibold">
              MF Cosméticos Profissionais · Postura Consultiva no Salão
            </p>
          </div>
        </div>

      </div>
    </section>
  );
};
