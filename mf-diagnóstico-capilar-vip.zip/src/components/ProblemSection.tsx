import React from 'react';
import { AlertCircle, HelpCircle, MessageSquareOff, ShoppingBag, Clock, Trophy, ArrowRight } from 'lucide-react';

export const ProblemSection: React.FC = () => {
  const challenges = [
    {
      icon: AlertCircle,
      title: 'Queixas que surgem de última hora',
      description: 'Clientes que chegam na cadeira reclamando de ressecamento severo, falta de brilho ou quebra repentina dos fios, pegando você de surpresa.',
    },
    {
      icon: HelpCircle,
      title: 'Cliente confusa sobre o que priorizar',
      description: 'Muitas clientes não entendem a diferença entre nutrição, reconstrução ou hidratação e não sabem quais cuidados seus fios realmente precisam.',
    },
    {
      icon: MessageSquareOff,
      title: 'Dificuldade para justificar o tratamento',
      description: 'Explicar na correria do dia a dia por que aquele protocolo profissional específico é indispensável para a saúde do cabelo dela.',
    },
    {
      icon: ShoppingBag,
      title: 'Compras de produtos no varejo sem orientação',
      description: 'Clientes que investem em cosméticos comuns de prateleira que não atendem às necessidades capilares reais, em vez de tratarem no salão.',
    },
    {
      icon: Clock,
      title: 'Distanciamento entre as visitas',
      description: 'O desafio constante de manter contato ativo e relacionamento com a cliente durante as semanas em que ela não vem ao salão.',
    },
    {
      icon: Trophy,
      title: 'Diferenciação em um mercado competitivo',
      description: 'A necessidade contínua de elevar o padrão do atendimento e mostrar uma postura verdadeiramente consultiva para se destacar dos concorrentes.',
    },
  ];

  return (
    <section className="py-20 bg-[#0B0F17] border-y border-slate-800/80 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Cabeçalho da Seção */}
        <div className="max-w-3xl mx-auto text-center space-y-4 mb-16">
          <span className="text-xs font-bold text-[#D4AF37] tracking-widest uppercase">
            A Realidade do Salão de Beleza
          </span>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-white tracking-tight leading-snug">
            Você conhece as necessidades dos cabelos das suas clientes ou só descobre quando elas chegam ao salão?
          </h2>
          <p className="text-slate-400 text-sm sm:text-base leading-relaxed">
            Identificar com antecedência o que a cliente relata sobre os fios abre espaço para conversas mais embasadas e indicações profissionais precisas.
          </p>
        </div>

        {/* Grade de 6 Desafios Comuns */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {challenges.map((item, index) => {
            const IconComponent = item.icon;
            return (
              <div
                key={index}
                className="p-6 rounded-2xl bg-[#0E1524] border border-slate-800/90 hover:border-[#D4AF37]/30 transition-all duration-300 flex flex-col justify-between group"
              >
                <div className="space-y-4">
                  <div className="w-12 h-12 rounded-xl bg-[#141C2E] border border-slate-800 flex items-center justify-center text-[#E8C872] group-hover:bg-[#D4AF37]/10 group-hover:text-[#D4AF37] transition-colors">
                    <IconComponent className="w-6 h-6" />
                  </div>
                  <h3 className="text-lg font-bold text-white group-hover:text-[#F5E6CA] transition-colors">
                    {item.title}
                  </h3>
                  <p className="text-slate-400 text-sm leading-relaxed">
                    {item.description}
                  </p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Fechamento Reflexivo Oficial */}
        <div className="mt-12 max-w-3xl mx-auto p-6 sm:p-8 rounded-2xl bg-gradient-to-r from-[#131B2A] via-[#162033] to-[#131B2A] border border-[#D4AF37]/40 text-center shadow-lg">
          <p className="text-lg sm:text-xl font-bold text-white mb-2">
            O primeiro passo para oferecer um tratamento adequado é conhecer melhor a necessidade da cliente.
          </p>
          <p className="text-xs sm:text-sm text-slate-300">
            O diagnóstico capilar digital auxilia o profissional a compreender as queixas relatadas e transformar essa conversa em um atendimento muito mais completo.
          </p>
        </div>

      </div>
    </section>
  );
};
