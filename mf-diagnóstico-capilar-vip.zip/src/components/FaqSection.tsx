import React, { useState } from 'react';
import { ChevronDown, HelpCircle } from 'lucide-react';

interface FaqItem {
  question: string;
  answer: string;
}

export const FaqSection: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const faqs: FaqItem[] = [
    {
      question: '1. O que é o MF Diagnóstico Capilar?',
      answer: 'O MF Diagnóstico Capilar é uma ferramenta digital online que permite às clientes do salão responderem a perguntas estruturadas sobre seus hábitos, queixas e necessidades capilares. As informações são organizadas e enviadas ao cabeleireiro, servindo como ponto de partida para conversas técnicas mais personalizadas sobre tratamentos e cuidados.',
    },
    {
      question: '2. Para quem o diagnóstico é indicado?',
      answer: 'É indicado para cabeleireiros autônomos, coloristas, terapeutas capilares e proprietários de salões de beleza que desejam aproximar o relacionamento com suas clientes, valorizar seu atendimento técnico e criar novas oportunidades de recomendação de tratamentos e cuidados.',
    },
    {
      question: '3. Como minha cliente acessa o diagnóstico?',
      answer: 'De forma muito simples: o profissional compartilha um link direto por meio do WhatsApp, mensagem privada ou redes sociais. A cliente clica no link e responde ao questionário diretamente no navegador do seu smartphone, sem complicações.',
    },
    {
      question: '4. Como recebo as respostas da cliente?',
      answer: 'No funcionamento atual do serviço, após a contratação e o cadastro do WhatsApp da profissional no sistema, as respostas preenchidas pela cliente são encaminhadas diretamente para o número de WhatsApp cadastrado, prontas para visualização.',
    },
    {
      question: '5. Preciso instalar algum aplicativo?',
      answer: 'Não. Nem o cabeleireiro nem a cliente precisam baixar ou instalar nenhum aplicativo. A ferramenta funciona 100% online através do navegador de internet de qualquer smartphone, tablet ou computador.',
    },
    {
      question: '6. O diagnóstico substitui a avaliação presencial do cabeleireiro?',
      answer: 'Não. O diagnóstico capilar digital não substitui o toque físico, o teste de mecha, a avaliação presencial minuciosa do profissional de salão nem consultas com profissionais de saúde (como médicos dermatologistas ou tricologistas). Ele atua exclusivamente como um apoio para coletar as queixas informadas pela cliente e direcionar a conversa inicial.',
    },
    {
      question: '7. O diagnóstico garante a venda de tratamentos?',
      answer: 'Não. A ferramenta não garante vendas, aumento de clientes ou resultados financeiros automáticos. Ela organiza as informações e apoia o cabeleireiro na condução de um atendimento consultivo e profissional, cabendo a cada profissional negociar e realizar o atendimento de acordo com suas práticas.',
    },
    {
      question: '8. Como funciona a contratação?',
      answer: 'A contratação é realizada de forma direta com a equipe comercial da MF Cosméticos Profissionais através do nosso WhatsApp oficial. Por lá, apresentamos o funcionamento, tiramos dúvidas e alinhamos as condições de ativação para o seu salão.',
    },
    {
      question: '9. Como funciona o cadastro do WhatsApp profissional?',
      answer: 'Após a contratação do serviço com a equipe comercial, é feito o cadastro do número de telefone celular/WhatsApp do cabeleireiro ou do salão no sistema, permitindo que o questionário exclusivo direcione as respostas das clientes para o contato correto.',
    },
    {
      question: '10. Como posso utilizar o diagnóstico na minha estratégia comercial?',
      answer: 'Você pode enviar o link para clientes que estão há semanas sem visitar o salão, disponibilizar o link na bio do Instagram para atrair pessoas interessadas em cuidar dos cabelos, ou utilizar como etapa prévia antes de agendamentos de procedimentos químicos ou cronogramas capilares.',
    },
    {
      question: '11. Como funciona o tratamento dos dados pessoais das clientes?',
      answer: 'As informações preenchidas no questionário têm como finalidade exclusiva permitir que a profissional de beleza compreenda as necessidades informadas e faça o atendimento solicitado. O tratamento dessas informações deve respeitar a legislação aplicável de proteção de dados pessoais.',
    },
  ];

  const toggleFaq = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <section id="faq" className="py-20 lg:py-28 bg-[#0B0F17] border-y border-slate-800/80 relative">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Cabeçalho */}
        <div className="text-center space-y-4 mb-16">
          <span className="text-xs font-bold text-[#D4AF37] tracking-widest uppercase">
            Esclareça suas dúvidas
          </span>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-white tracking-tight leading-snug">
            Perguntas Frequentes
          </h2>
          <p className="text-slate-400 text-sm sm:text-base leading-relaxed">
            Respostas claras e transparentes sobre o funcionamento, contratação e uso do MF Diagnóstico Capilar.
          </p>
        </div>

        {/* Acordeão de Perguntas */}
        <div className="space-y-4 text-left">
          {faqs.map((faq, index) => {
            const isOpen = openIndex === index;
            return (
              <div
                key={index}
                className="rounded-2xl bg-[#0E1524] border border-slate-800/90 overflow-hidden transition-all duration-200"
              >
                <button
                  onClick={() => toggleFaq(index)}
                  className="w-full p-5 sm:p-6 text-left flex items-center justify-between gap-4 hover:bg-[#131B2A] transition-colors"
                  aria-expanded={isOpen}
                >
                  <span className="text-sm sm:text-base font-bold text-white leading-snug">
                    {faq.question}
                  </span>
                  <div className={`w-8 h-8 rounded-full bg-[#141C2E] flex items-center justify-center shrink-0 text-[#E8C872] transition-transform duration-300 ${isOpen ? 'rotate-180 bg-[#D4AF37]/20 text-[#D4AF37]' : ''}`}>
                    <ChevronDown className="w-4 h-4" />
                  </div>
                </button>

                {isOpen && (
                  <div className="px-5 pb-6 sm:px-6 sm:pb-6 text-slate-300 text-xs sm:text-sm leading-relaxed border-t border-slate-800/60 pt-4">
                    {faq.answer}
                  </div>
                )}
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
