/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Navbar } from './components/Navbar';
import { HeroSection } from './components/HeroSection';
import { ProblemSection } from './components/ProblemSection';
import { SolutionSection } from './components/SolutionSection';
import { HowItWorksSection } from './components/HowItWorksSection';
import { DemoPreviewSection } from './components/DemoPreviewSection';
import { HairdresserBenefitsSection } from './components/HairdresserBenefitsSection';
import { RoiCalculatorSection } from './components/RoiCalculatorSection';
import { CredibilitySection } from './components/CredibilitySection';
import { OfferSection } from './components/OfferSection';
import { FaqSection } from './components/FaqSection';
import { FinalCtaSection } from './components/FinalCtaSection';
import { FloatingWhatsapp } from './components/FloatingWhatsapp';
import { Footer } from './components/Footer';

export default function App() {
  return (
    <div className="min-h-screen bg-[#080C14] text-slate-100 flex flex-col selection:bg-[#D4AF37]/30 selection:text-white">
      {/* Top Bar Navigation */}
      <Navbar />

      {/* Main Content Flow */}
      <main className="flex-grow">
        {/* Seção 1: Primeira Dobra (Proposta de Valor) */}
        <HeroSection />

        {/* Seção 2: Identificação do Problema no Salão */}
        <ProblemSection />

        {/* Seção 3: Apresentação da Solução */}
        <SolutionSection />

        {/* Seção 4: Como Funciona na Prática (5 Etapas) */}
        <HowItWorksSection />

        {/* Seção 5: Demonstração do Produto & Link Oficial */}
        <DemoPreviewSection />

        {/* Seção 6: Benefícios Exclusivos para Cabeleireiros */}
        <HairdresserBenefitsSection />

        {/* Seção 8: Simulador de Retorno do Investimento (Interativo) */}
        <RoiCalculatorSection />

        {/* Seção 9: Credibilidade e Confiança (MF 32+ anos) */}
        <CredibilitySection />

        {/* Seção 10: Oferta e Contratação */}
        <OfferSection />

        {/* Seção 11: Perguntas Frequentes (11 Perguntas em Acordeão) */}
        <FaqSection />

        {/* Seção 12: Chamada Final */}
        <FinalCtaSection />
      </main>

      {/* Botão Flutuante de WhatsApp */}
      <FloatingWhatsapp />

      {/* Rodapé Institucional */}
      <Footer />
    </div>
  );
}
