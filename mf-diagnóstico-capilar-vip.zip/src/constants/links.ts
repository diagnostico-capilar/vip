/**
 * Links e informações oficiais do MF Diagnóstico Capilar
 * Centralizados para garantir conformidade estrita com o briefing.
 */

export const WHATSAPP_PHONE_DISPLAY = '(19) 9.8359-6993';
export const WHATSAPP_NUMBER = '5519983596993';

// Mensagens oficiais padronizadas pelo briefing
export const WHATSAPP_MESSAGES = {
  HAIRDRESSER: 'Olá! Quero conhecer o MF Diagnóstico Capilar para utilizar no meu salão. Gostaria de saber como funciona e quais são as condições de contratação.',
  DEMO: 'Olá! Gostaria de ver uma demonstração do MF Diagnóstico Capilar antes de contratar.',
  DISTRIBUTOR: 'Olá! Sou distribuidor/representante de cosméticos e gostaria de conhecer o MF Diagnóstico Capilar como uma solução para oferecer aos salões parceiros. Poderiam me explicar como funciona?',
} as const;

/**
 * Construtor seguro de URL para o WhatsApp
 */
export function getWhatsAppUrl(message: string): string {
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
}

// Link oficial do questionário existente em produção
export const OFFICIAL_DIAGNOSIS_URL = 'https://diagnosticovip.vercel.app/diagnostico/mfcosmeticos';

export const COMPANY_NAME = 'MF Cosméticos Profissionais';
export const COMPANY_EXPERIENCE = 'Mais de 32 anos de experiência no mercado profissional';
